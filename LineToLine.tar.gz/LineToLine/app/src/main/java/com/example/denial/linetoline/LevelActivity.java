package com.example.denial.linetoline;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by denial on 09.05.16.
 */
public class LevelActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.levels_layout);
        int myLevel = getIntent().getExtras().getInt("myNumberOfLevel");
        Button bt1 = (Button) findViewById(R.id.bt1);
        Button bt2 = ((Button) findViewById(R.id.bt2));
        Button bt3 = ((Button) findViewById(R.id.bt3));
        Button bt4 = ((Button) findViewById(R.id.bt4));
        Button bt5 = ((Button) findViewById(R.id.bt5));
        Button bt6 = ((Button) findViewById(R.id.bt6));
        Button bt7 = ((Button) findViewById(R.id.bt7));
        Button bt8 = ((Button) findViewById(R.id.bt8));
        switch(myLevel)
        {
            case 1:
                bt2.setBackgroundColor(Color.BLUE);
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
        }
    }


    public void toMain(View view) {
        Intent intent = new Intent(LevelActivity.this, MainActivity.class);
        startActivity(intent);
    }

    public void toFirstLevel(View view) {
        Intent intent = new Intent(LevelActivity.this, GameActivity_Level1.class);
        startActivity(intent);
    }
}
