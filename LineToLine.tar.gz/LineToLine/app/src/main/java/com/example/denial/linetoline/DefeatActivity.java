package com.example.denial.linetoline;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Created by denial on 09.05.16.
 */
public class DefeatActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.defeat_layout);
    }

    public void toMain(View view) {
        Intent intent = new Intent(DefeatActivity.this, MainActivity.class);
        intent.putExtra("myNumberOfLevel",0);
        startActivity(intent);
    }

    public void toThisLevel(View view) {
        Intent intent = new Intent(DefeatActivity.this, GameActivity_Level1.class);
        startActivity(intent);
    }
}

