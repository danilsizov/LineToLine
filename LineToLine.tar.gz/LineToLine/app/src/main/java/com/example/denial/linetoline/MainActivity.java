package com.example.denial.linetoline;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    int maxLevel=0;
    int i;
    SharedPreferences sPref;
    final String MAX_LEVEL = "saved_max_level";
    final String MY_LEVEL = "saved_my_level";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences.Editor ed = sPref.edit();
        ed.putInt(MAX_LEVEL, 1);
        ed.putInt(MY_LEVEL, 1);
        ed.commit();

    }

    public void toLevels(View view) {
        if(i>0) {
            int myLevel = getIntent().getExtras().getInt("myNumberOfLevel");
            if (myLevel > maxLevel)
                maxLevel = myLevel;
        }
        i++;


        Intent intent = new Intent(MainActivity.this, LevelActivity.class);
        intent.putExtra("myNumberOfLevel",maxLevel);
        startActivity(intent);
    }


    public void exit(View view) {
        exit(view);
    }

}
