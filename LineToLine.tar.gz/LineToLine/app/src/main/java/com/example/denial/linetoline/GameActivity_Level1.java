    package com.example.denial.linetoline;

    import android.app.Activity;
    import android.content.Context;
    import android.content.Intent;
    import android.content.SharedPreferences;
    import android.graphics.Bitmap;
    import android.graphics.Canvas;
    import android.graphics.Color;
    import android.graphics.Paint;
    import android.graphics.Path;
    import android.os.Bundle;
    import android.view.MotionEvent;
    import android.view.View;
    import android.widget.Toast;

    public class GameActivity_Level1 extends Activity {

        DrawingView dv ;
        private Paint mPaint;
        SharedPreferences sPref;
        final String MAX_LEVEL = "saved_max_level";
        final String MY_LEVEL = "saved_my_level";

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            dv = new DrawingView(this);
            setContentView(dv);
            mPaint = new Paint();
            mPaint.setAntiAlias(true);
            mPaint.setDither(true);
            mPaint.setColor(Color.GREEN);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeJoin(Paint.Join.ROUND);
            mPaint.setStrokeCap(Paint.Cap.ROUND);
            mPaint.setStrokeWidth(50);
        }

        public class DrawingView extends View {

            int indicator;
            int badroad1;
            int badroad2;
            int badroad3;
            int myNumberOfLevel;
            int one,two,three;
            int firPoint,secPoint,thiPoint;
            public int width;
            public  int height;
            private Bitmap  mBitmap;
            private Canvas  mCanvas;
            private Path    mPath;
            private Paint   mBitmapPaint;
            Context context;
            private Paint circlePaint;
            private Path circlePath;

            public DrawingView(Context c) {
                super(c);
                context=c;
                mPath = new Path();
                mBitmapPaint = new Paint(Paint.DITHER_FLAG);
                circlePaint = new Paint();
                circlePath = new Path();
                circlePaint.setAntiAlias(true);
                circlePaint.setColor(Color.BLUE);
                circlePaint.setStyle(Paint.Style.STROKE);
                circlePaint.setStrokeJoin(Paint.Join.MITER);
                circlePaint.setStrokeWidth(4f);
                indicator=0;
                badroad1=0;
                badroad2=0;
                badroad3=0;
                one=0;
                two=0;
                three=0;
                firPoint=0;
                secPoint=0;
                thiPoint=0;
                myNumberOfLevel=1;
            }

            @Override
            protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);

                mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                mCanvas = new Canvas(mBitmap);
            }

            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                Paint p;
                p = new Paint();
                p.setColor(Color.RED);
                // толщина линии = 10
                p.setStrokeWidth(50);

                canvas.drawCircle(100, 500, 50, p);
                canvas.drawCircle(500, 500, 50, p);
                canvas.drawCircle(500, 100, 50, p);
                canvas.drawLine( 100,500,500,500,p);
                canvas.drawLine( 100,500,500,100,p);
                canvas.drawLine( 500,500,500,100,p);
                canvas.drawBitmap( mBitmap, 0, 0, mBitmapPaint);
                canvas.drawPath( mPath,  mPaint);
                canvas.drawPath( circlePath,  circlePaint);
            }

            private float mX, mY;
            private static final float TOUCH_TOLERANCE = 4;

            private void touch_start(float x, float y) {
                mPath.reset();
                mPath.moveTo(x, y);
                mX = x;
                mY = y;
            }

            private void touch_move(float x, float y) {
                float dx = Math.abs(x - mX);
                float dy = Math.abs(y - mY);
                if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                    mPath.quadTo(mX, mY, (x + mX)/2, (y + mY)/2);
                    mX = x;
                    mY = y;

                    circlePath.reset();
                    circlePath.addCircle(mX, mY, 30, Path.Direction.CW);
                }
            }


            private void touch_up() {
                mPath.lineTo(mX, mY);
                circlePath.reset();
                // commit the path to our offscreen
                mCanvas.drawPath(mPath,  mPaint);
                // kill this so we don't double draw
                mPath.reset();
            }

            public boolean getWin(int one, int two, int three)
            {
                if(one!=0&&two!=0&&three!=0)
                {
                    return true;
                }
                return false;
            }

            @Override
            public boolean onTouchEvent(MotionEvent event) {
                float x = event.getX();
                float y = event.getY();

                if(badroad1>=2||badroad2>=2||badroad3>=2)
                {
                    Intent intent = new Intent(GameActivity_Level1.this, DefeatActivity.class);
                    startActivity(intent);
                }
                if(getWin(badroad1,badroad2,badroad3)==true)
                {
                    sPref = getPreferences(MODE_PRIVATE);
                    SharedPreferences.Editor ed = sPref.edit();
                    int getMaxLevel = sPref.getInt(MAX_LEVEL, indicator);
                    ed.putInt(MAX_LEVEL, 1);
                    ed.putInt(MY_LEVEL, 1);
                    ed.commit();
                    Intent intent = new Intent(GameActivity_Level1.this, WInActivity.class);
                    startActivity(intent);
                }

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if(x>50&&x<150&&y>450&&y<550)
                        {

                            badroad1++;
                            if(indicator==0)
                            {
                                touch_start(100, 500);
                            }
                            indicator++;
                            if (indicator!=0)
                            {
                                touch_move(100, 500);
                                touch_up();
                                touch_start(100, 500);
                                invalidate();
                            }
                        }

                        else if(x>450&&x<550&&y>450&&y<550)
                        {
                            badroad2++;
                            if(indicator==0)
                            {
                                touch_start(500, 500);
                            }
                            indicator++;
                            if (indicator!=0)
                            {
                                touch_move(500, 500);
                                touch_up();
                                touch_start(500, 500);
                                invalidate();
                            }
                        }
                        else if(x>450&&x<550&&y>50&&y<150)
                        {
                            badroad3++;
                            if(indicator==0)
                            {
                                touch_start(500, 100);
                            }
                            indicator++;
                            if (indicator!=0)
                            {
                                touch_move(500, 100);
                                touch_up();
                                touch_start(500, 100);
                                invalidate();
                            }
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        break;
                    case MotionEvent.ACTION_UP:
                        break;
                }
                return true;
            }
        }
    }