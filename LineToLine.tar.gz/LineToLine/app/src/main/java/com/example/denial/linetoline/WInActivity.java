package com.example.denial.linetoline;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Created by denial on 09.05.16.
 */
public class WInActivity extends Activity {

    int maxLevel=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.win_layout);
        int myLevel = getIntent().getExtras().getInt("myNumberOfLevel");
        if(myLevel>maxLevel)
        {
            maxLevel=myLevel;
        }


    }

    public void toMain(View view) {

        Intent intent = new Intent(WInActivity.this, MainActivity.class);
        intent.putExtra("myNumberOfLevel",maxLevel);
        startActivity(intent);

    }

    public void toNextLevel(View view) {


        int myLevel = getIntent().getExtras().getInt("myNumberOfLevel");

        switch (myLevel)
        {
            case 1:
                Intent intent1 = new Intent(WInActivity.this, GameActivity_Level2.class);
                startActivity(intent1);
                break;
            case 2:
                Intent intent2 = new Intent(WInActivity.this, MainActivity.class);
                startActivity(intent2);
        }

    }
}
